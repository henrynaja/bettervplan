let newshead = "Neuigkeiten"

/*Blendet die Hofdienst Box aus*/
const hofdienst = document.querySelector("table.info  tr:nth-child(2)  td");
if (hofdienst.innerHTML.includes("Hofdienst:")){
  hofdienst.setAttribute("id", "hofdienst")
  document.body.style.setProperty('--main-hofdienst', "none");
}


/*Color Code zum teilen mit Freunden erstellen*/
/*Dark Mode Button hinzufügen*/
/*
let header = document.createElement('button');
header.textContent = "Dark Mode";
header.id = "darkmode";
header.setAttribute("onclick", "darkMode()");
document.body.appendChild(header);
*/
/*Fügt eigenes Icon für den Tab ein*/ 
const link = document.createElement('link');
link.href = 'https://cdn.discordapp.com/attachments/773914479384985650/1021425143467229194/bvp.png';
link.rel = 'icon';

document.getElementsByTagName('head')[0].appendChild(link);

/*Verbuggten Style der Tabelle zurücksetzen*/
const nodeList = document.querySelectorAll("td");
for (let i = 0; i < nodeList.length; i++) {
  nodeList[i].style = "";
}

/*Default Farben im LocalStorage speichern*/
if (localStorage.getItem("bgColor") == null){
  console.log("HALLO")
  localStorage.setItem("bgColor", "#010409")
}
/*if (localStorage.getItem("oddColor") == null){
  console.log("HALLO")
  localStorage.setItem("oddColor", "#0D1117")
}*/
if (localStorage.getItem("evenColor") == null){
  console.log("HALLO")
  localStorage.setItem("evenColor", "#161B22")
}
if (localStorage.getItem("roomColor") == null){
  console.log("HALLO")
  localStorage.setItem("roomColor", "#22712E")
}
if (localStorage.getItem("eventColor") == null){
  console.log("HALLO")
  localStorage.setItem("eventColor", "#1B12B1")
}
if (localStorage.getItem("newColor") == null){
  console.log("HALLO")
  localStorage.setItem("newColor", "#E61367")
}
/*Farben*/
let bgColor = localStorage.getItem("bgColor");
let oddColor = localStorage.getItem("oddColor");
let evenColor = localStorage.getItem("evenColor");
let roomColor = localStorage.getItem("roomColor");
let eventColor = localStorage.getItem("eventColor");
let newColor = localStorage.getItem("newColor");
console.log([bgColor, oddColor, evenColor, roomColor, eventColor, newColor])


document.body.style.setProperty('--main-bg-color', bgColor);

/*Verbesserung der Tabellenbeschriftungen*/
document.querySelector("tr.list:nth-child(2) th:nth-child(2)").innerHTML = "Stunde(n)"
document.querySelector("tr.list:nth-child(2) th:nth-child(3)").innerHTML = "statt Lehrer"
document.querySelector("tr.list:nth-child(2) th:nth-child(4)").innerHTML = "statt Fach"
document.querySelector("tr.list:nth-child(2) th:nth-child(5)").innerHTML = "Lehrer bzw. Vertretung"
document.querySelector("tr.list:nth-child(2) th:nth-child(8)").innerHTML = "Anmerkung"
document.querySelector("th.info").innerHTML = newshead

let counter = 1
function abbrevTeacher(counter){
  if (document.querySelector(`center:nth-child(2) > table:nth-child(4) > tbody:nth-child(1) > tr:nth-child(3) > td:nth-child(3) > span:nth-child(1)`).innerHTML == "Bg"){
    document.querySelector(`center:nth-child(2) > table:nth-child(4) > tbody:nth-child(1) > tr:nth-child(6) > td:nth-child(3)`).innerHTML = "Bruggaier";
  }
}

abbrevTeacher(counter)
counter = counter + 1

function abbrevFach(fachcounter){
  if (document.querySelector(`center:nth-child(2) > table:nth-child(4) > tbody:nth-child(1) > tr:nth-child(${fachcounter}) > td:nth-child(4)`).innerHTML == "D" || document.querySelector(`center:nth-child(2) > table:nth-child(4) > tbody:nth-child(1) > tr:nth-child(${fachcounter}) > td:nth-child(4)`).innerHTML == "D1"){
    document.querySelector(`center:nth-child(2) > table:nth-child(4) > tbody:nth-child(1) > tr:nth-child(${fachcounter}) > td:nth-child(4)`).innerHTML = "Deutsch";
  }
}
 let fcounter = 4

while (fcounter < 40){
  console.log(fcounter)
  abbrevFach(fcounter)
  fcounter = fcounter + 1
}
/*
#\31  > center:nth-child(2) > table:nth-child(4) > tbody:nth-child(1) > tr:nth-child(4) > td:nth-child(4)
*/
