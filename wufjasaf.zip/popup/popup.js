localStorage.setItem("oddColor", "LALALLALA")
console.log("HALLO")