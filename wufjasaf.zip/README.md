# Bettervplan
Ein Addon für Firefox um den Vertretungsplan der Musterschule zu verbessern.

# Funktionen
- **Dark Mode**
- verbesserte Beschriftung der Tabelle
- ein- und ausblenden von nicht benötigten Informationen
- eigene Akzentfarben [soon]
